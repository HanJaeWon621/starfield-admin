package vo;

public class TntVO {
	
	public String busi_tnt_seq;//영업테넌트순번
	public String bcn_cd;//지점코드
	public String brnd_cd;//브랜드코드
	public String busi_tnt_cd;//영업테넌트코드
	public String busi_tnt_nm_ko;//영업테넌트명
	public String busi_tnt_nm_en;//영업테넌트명_영문
	public String tnt_div_cd;//테넌트구분코드
	public String sum_tnt_cd;//집계테넌트코드
	public String hq_cd;//본사코드
	public String fd_yn;//푸드코드여부 
	public String cate_vip;//카테고리VIP
	public String cate_cd1;//카테고리(대)
	public String cate_cd2;//카테고리(중)
	public String cate_cd3;//카테고리(소)
	public String new_div_cd;//신규구분코드
	public String cont_strt_dt;//계약시작일자
	public String cont_end_dt;//계약종료일자
	public String room_num;//호수
	public int  cnt;
	public int sts;//상태	
	public String reg_usr;//등록자
	public String mod_usr;//수정자
}
