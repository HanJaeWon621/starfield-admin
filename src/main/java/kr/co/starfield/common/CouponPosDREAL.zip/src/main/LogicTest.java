package main;

import java.net.*;
import java.util.Scanner;

import org.apache.commons.lang.StringUtils;

import java.io.*;

public class LogicTest {

	public static void main(String[] args) throws UnknownHostException, IOException {
		String prcCd    = "00";
		String dealNo  = "8888";// 8888
		String sendDate= "20161210";
		String sendTime= "123014";
		String bcnCd   = "01";
		String tntCdP  = "0017";// 4001
		String posNo   = "7777";
		String casherNo= "666666";
		String saleDate= "20160630";
		String saleTime= "123010";
		String cpTp    ="1";
		String cpNo    = "011609002000000054";
		String saleAmt ="00000050000";
		String ext="";
		
        String sendMsg0000_00 = "0200" + prcCd + sendDate+ sendTime + bcnCd + tntCdP + posNo + dealNo + casherNo + saleDate + saleTime+cpTp
				+ cpNo + saleAmt;// 테스트완료
        String sendMsg =sendMsg0000_00;
        sendMsg = StringUtils.rightPad(sendMsg0000_00, 200, " ");
		//String sendMsg = sendMsg0000_00;
		System.out.println(">>>>>>>>>>>>>>>>>" + sendMsg);
		CouponPosIFProcess CPIP = new CouponPosIFProcess();
		CPIP.prcPosByte(sendMsg);
	}

}
