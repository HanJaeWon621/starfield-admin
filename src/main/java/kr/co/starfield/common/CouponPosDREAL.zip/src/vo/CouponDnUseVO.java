package vo;
public class CouponDnUseVO {
	public String cp_use_sts_cd="";
	public String cp_iss_bcd_id="";
	public String bcn_cd="";
	public String cp_cofm_dt="";
	public String busi_tnt_cd="";
	public String pos_no="";
	public String deal_no;
	public String cncl_deal_no;
	
}