package vo;

public class CouponIssMstVO {	
	//쿠폰발급
	public String cp_iss_mst_seq;//쿠폰발급마스터순번
	public String cp_iss_sub_seq;//발급부순번
	public String tnt_seq;//테넌트순번
	public String img_seq;//쿠폰발급바코드이미지순번
	public String cp_iss_bcd_id;//쿠콘발급바코드ID
	public String busi_tnt_cd;//영업테넌트코드
	public String bcn_cd;
	public int    iss_cnt;//쿠폰바코드 카운트 
	
}
