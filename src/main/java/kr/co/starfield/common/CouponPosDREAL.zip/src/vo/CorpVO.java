package vo;

public class CorpVO {
	
	public String corp_cd;//법인코드
	public String corp_nm;//법인명
	public String tel_no;//전화번호
	public String fax_no;//팩스번호
	public String post_no;//우편번호
	public String addr;//주소
	public String use_yn;//사용여부
	public String strt_dt;//시작일자
	public String end_dt;//종료일자 
	public String shrs_map_cd;//SHRS매핑코드
	public String ac_co_cd;//회계회사코드
	public int sts;//상태
	public int cnt;
	public String reg_usr;//등록자
	public String mod_usr;//수정자
}
