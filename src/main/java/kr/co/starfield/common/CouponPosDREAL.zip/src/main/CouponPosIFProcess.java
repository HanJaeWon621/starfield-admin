package main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import vo.CouponDnUseVO;
import vo.CouponIssMstVO;
import vo.CouponLogVO;
import vo.CouponVO;

public class CouponPosIFProcess {
	// static String configFile =
	// "com/sktelecom/tdrive/util/mesg/mybatis-config.xml";

	static String configFile = "mybatis-config.xml";/// BlogTest/src/main/birdhead/mybatis-config.xml
	static InputStream inputStream;
	static SqlSessionFactory sqlSessionFactory;
	static SqlSession sqlSession;

	/*
	 * String configFile = "mybatis-config.xml";///
	 * BlogTest/src/main/birdhead/mybatis-config.xml InputStream inputStream;
	 * SqlSessionFactory sqlSessionFactory; SqlSession sqlSession;
	 */
	public static void main(String[] args) {

	}

	// 조회처리(사용처리_선처리)
	@SuppressWarnings("finally")
	public byte[] prcPosByteOld(String sendMsg) {

		String msg = sendMsg;// 조회
		String msg2 = "안녕하세요";
		String r_Str = "";
		String subFileNm1 = "";
		String cp_cofm_dt = "";
		byte[] rtnMsgByte = new byte[200];
		String res_ext_val = "                                   ";
		// 조회 전문
		String sts_len = ""; // 전문길이4
		String sts_div = ""; // 전문구분 조회:00 사용완료 : '01', 사용취소:09 망상취소:90 조회취소:02
		String orig_sts_div = ""; // 전문구분 조회:00 사용완료 : '01',
		String req_dt = ""; // 조회일자8
		String req_tm = "";// 조회시간6
		String jp_cd = "";// 점포코드2
		String tnt_cd = "";// 테넌트코드4
		String pos_no = "";// 포스번호 4
		String deal_no = "";// 거래번호 4
		String cacher_no = "";// Casher번호
		String sale_dt = "";// 영업일자8
		String sale_tm = "";// 영업시간6
		String cp_type = "";// 쿠폰유형1 1:에누리 2:할인
		String cp_no = "";// 쿠폰번호 18 바코드번호
		String sale_amt = "";// 매출금액

		String resp_code = "0000";
		String resp_str = "정상";
		String resp_msg = "";
		String check1 = "";// 유효일자체크
		String check2 = "S";// 바코드유무
		String check3 = "";// 최소사용금액체크
		String check4 = "";// 쿠폰종류체크
		String check5 = "";// 해당 테넌트에서 사용 가능 쿠폰인지 조회
		String check6 = "";// 조회 전문 길이체크
		String check7 = "";// 조회 중복 체크

		// 응답시에만 사용
		String rtn_cd = "";// 응답코드 0000 '정상', '0001' : 미발행, '0002': 이미사용, 그 외
		String rtn_msg = "";// 응답메시지 60
		String sale_evt_cd = "";// 행사코드 9
		String cp_app_meth = "";// 쿠폰적용방법 1:금액 2:율(DB)
		String cp_app_amt = "";// 쿠폰적용값 11(DB)
		String cp_max_sale_amt = "";// 쿠폰최대할인값 11(DB)
		String cp_kind_cd = "";
		String cp_use_sts_cd = "";
		String ext_val = "";// 여유필드 119 //공통

		try {
			setDbInfoLoad();
			// 로그 남기기
			// 전문관련 변수
			/*
			 * sts_len = msg.substring(0, 4); // 전문길이4 sts_div =
			 * msg.substring(4, 6); // 전문구분 조회:00 사용완료 : '01', 사용취소:09 망상취소:90
			 * 조회취소:02 orig_sts_div = msg.substring(4, 6); // 전문구분 조회:00 사용완료 :
			 * '01', req_dt = msg.substring(6, 14); // 조회일자8 req_tm =
			 * msg.substring(14, 20);// 조회시간6 jp_cd = msg.substring(20, 22);//
			 * 점포코드2 tnt_cd = msg.substring(22, 26);// 테넌트코드4 pos_no =
			 * msg.substring(26, 30);// 포스번호 4 deal_no = msg.substring(30,
			 * 34);// 거래번호 4 cacher_no = msg.substring(34, 40);// Casher번호
			 * sale_dt = msg.substring(40, 48);// 영업일자8 sale_tm =
			 * msg.substring(48, 54);// 영업시간6 cp_type = msg.substring(54, 55);//
			 * 쿠폰유형1 1:에누리 2:할인 cp_no = msg.substring(55, 73);// 쿠폰번호 18 바코드번호
			 * sale_amt = msg.substring(73, 84);// 매출금액
			 */
			try {
				sts_div = msg.substring(4, 6);// 전문구분 조회:00 사용완료 :
			} catch (StringIndexOutOfBoundsException e) {
				sts_div = "";
			}
			try {
				orig_sts_div = msg.substring(4, 6);// 전문구분 조회:00 사용완료 :
			} catch (StringIndexOutOfBoundsException e) {
				orig_sts_div = "";
			}
			req_dt = msg.substring(6, 14);// 조회일자8
			try {
				req_dt = msg.substring(6, 14);// 조회일자8
			} catch (StringIndexOutOfBoundsException e) {
				req_dt = "";
			}
			try {
				req_tm = msg.substring(14, 20);// 조회시간6
			} catch (StringIndexOutOfBoundsException e) {
				req_tm = "";
			}
			try {
				jp_cd = msg.substring(20, 22);// 점포코드2
			} catch (StringIndexOutOfBoundsException e) {
				jp_cd = "";
			}
			try {
				tnt_cd = msg.substring(22, 26);// 테넌트코드4
			} catch (StringIndexOutOfBoundsException e) {
				tnt_cd = "";
			}
			try {
				pos_no = msg.substring(26, 30);// 포스번호 4
			} catch (StringIndexOutOfBoundsException e) {
				pos_no = "";
			}

			try {
				deal_no = msg.substring(30, 34);// 거래번호 4
			} catch (StringIndexOutOfBoundsException e) {
				deal_no = "";
			}
			try {
				cacher_no = msg.substring(34, 40);// Casher번호
			} catch (StringIndexOutOfBoundsException e) {
				cacher_no = "";
			}
			try {
				sale_dt = msg.substring(40, 48);// 영업일자8
			} catch (StringIndexOutOfBoundsException e) {
				sale_dt = "";
			}

			try {
				sale_tm = msg.substring(48, 54);// 영업시간6
			} catch (StringIndexOutOfBoundsException e) {
				sale_tm = "";
			}
			try {
				cp_type = msg.substring(54, 55);// 쿠폰유형1 1:에누리 2:할인
			} catch (StringIndexOutOfBoundsException e) {
				cp_type = "";
			}
			try {
				cp_no = msg.substring(55, 73);// 쿠폰번호 18 바코드번호
			} catch (StringIndexOutOfBoundsException e) {
				cp_no = "";
			}

			try {
				sale_amt = msg.substring(73, 84);// 매출금액
			} catch (StringIndexOutOfBoundsException e) {
				sale_amt = "";
			}
			CouponLogVO clv = new CouponLogVO();
			// SqlSession
			sqlSession = sqlSessionFactory.openSession();
			if (checkLengMsg(msg).equals("N")) {// 바이트 길이가 작을때
				System.out.println("prcPos: 211111");
				rtnMsgByte = checkLengSendMsg(msg); //
				clv.sts_div = orig_sts_div;
				clv.req_dt = req_dt;
				clv.req_tm = req_tm;
				clv.jp_cd = jp_cd;
				clv.tnt_cd = tnt_cd;
				clv.pos_no = pos_no;
				clv.deal_no = deal_no;
				clv.cacher_no = cacher_no;
				clv.sale_dt = sale_dt;
				clv.sale_tm = sale_tm;
				clv.cp_type = cp_type;
				clv.cp_no = cp_no;
				clv.sale_amt = sale_amt;
				clv.resp_code = "0010";
				clv.resp_msg = "전문길이이상";
				clv.sale_evt_cd = "";
				clv.cp_app_meth = "";
				clv.cp_app_amt = "";
				clv.cp_max_sale_amt = "";
				
				sqlSession.insert("starfield.mapper.insertCouponPrcLog", clv);
			} else {
				System.out.println("prcPos: 311111");

				sts_len = msg.substring(0, 4); // 전문길이4
				sts_div = msg.substring(4, 6); // 전문구분 조회:00 사용완료 : '01',
												// 사용취소:09 망상취소:90 조회취소:02
				orig_sts_div = msg.substring(4, 6); // 전문구분 조회:00 사용완료 : '01',
				req_dt = msg.substring(6, 14); // 조회일자8
				req_tm = msg.substring(14, 20);// 조회시간6
				jp_cd = msg.substring(20, 22);// 점포코드2
				tnt_cd = msg.substring(22, 26);// 테넌트코드4
				pos_no = msg.substring(26, 30);// 포스번호 4
				deal_no = msg.substring(30, 34);// 거래번호 4
				cacher_no = msg.substring(34, 40);// Casher번호
				sale_dt = msg.substring(40, 48);// 영업일자8
				sale_tm = msg.substring(48, 54);// 영업시간6
				cp_type = msg.substring(54, 55);// 쿠폰유형1 1:에누리 2:할인
				cp_no = msg.substring(55, 73);// 쿠폰번호 18 바코드번호
				sale_amt = msg.substring(73, 84);// 매출금액

				subFileNm1 = jp_cd + tnt_cd;
				writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg, "req");

				sale_evt_cd = cp_no.substring(0, 9);// 행사코드 9

				// System.out.println("prcPos: 3");

				System.out.println("Server: 전문길이:" + sts_len + " 전문구분:" + sts_div);
				System.out.println("Server: 조회일자" + req_dt + " 조회시간:" + req_tm);
				System.out.println("Server: 점포코드" + jp_cd + " 테넌트코드:" + tnt_cd);
				System.out.println("Server: 포스번호:" + pos_no + " 거래번호:" + deal_no + " Casher번호:" + cacher_no);
				System.out.println("Server: 영업일자:" + sale_dt + " 영업시간:" + sale_tm);
				System.out.println("Server: 쿠폰유형:" + cp_type + " 쿠폰번호:" + cp_no);
				System.out.println("Server: 매출금액:" + sale_amt);

				CouponVO couponVO = new CouponVO();
				CouponIssMstVO couponIssMstVO = new CouponIssMstVO();
				CouponDnUseVO couponDnUseVO = new CouponDnUseVO();
				// 쿠폰마스터 조회를 위한 셋팅
				couponVO.cp_iss_bcd_id = cp_no;
				couponVO.sale_amt = sale_amt;
				couponVO.sts_div = sts_div;
				couponVO.busi_tnt_cd = tnt_cd;
				couponVO.cp_use_sts_cd =sts_div;
				couponVO.cp_kind_cd =cp_type;
				// 쿠폰바코드조회를 위한 셋팅
				couponIssMstVO.cp_iss_bcd_id = cp_no;
				couponIssMstVO.busi_tnt_cd = tnt_cd;
				couponIssMstVO.bcn_cd = jp_cd;

				couponDnUseVO.cp_iss_bcd_id = cp_no;

				CouponVO result = sqlSession.selectOne("starfield.mapper.selectCouponMst", couponVO);// 쿠폰마스터조회
				CouponIssMstVO result2 = sqlSession.selectOne("starfield.mapper.selectCouponIss", couponIssMstVO);// 쿠폰바코드조회
				List<CouponDnUseVO> result3List = sqlSession.selectList("starfield.mapper.selectCouponDownUse",
						couponDnUseVO);// 쿠폰바코드조회
				CouponDnUseVO result3 = new CouponDnUseVO();
				CouponIssMstVO result4 = new CouponIssMstVO();

				if (result == null) {
					resp_code = "0003";
					resp_str = "해당 바코드의 쿠폰이 존재하지 않습니다";
				} else {
					check1 = result.check1;
					check3 = result.check3;
					check7 = result.check7;

					cp_app_amt = result.cp_app_amt;// 쿠폰적용금액//던질값
					cp_max_sale_amt = result.cp_max_sale_amt;// 던질값
					cp_app_meth = result.cp_sale_div_cd;// 던질값
					cp_kind_cd = result.cp_kind_cd;// 던질값

					if (!cp_type.equals(cp_kind_cd)) {
						check4 = "E";
					}
					System.out.println(cp_type + ":쿠폰유형:" + cp_kind_cd);

					result4 = sqlSession.selectOne("starfield.mapper.selectCouponTntChk", couponIssMstVO);// 해당
																											// 테넌트에서
																											// 사용
																											// 쿠폰인지
																											// 조회

					if (result4 == null) {
						check5 = "E";
					}
				}

				if (result2 == null) {// 바코드 유무
					check2 = "E";
					// System.out.println("AAAAAAAAAAAAAAAAA");
				}
				if (result3List != null) {
					if (result3List.size() == 1) {
						result3 = (CouponDnUseVO) result3List.get(0);
						if (result3 == null) {
							System.out.println("아아아");
						} else {
							cp_use_sts_cd = result3.cp_use_sts_cd;
							cp_cofm_dt = result3.cp_cofm_dt;
							if (cp_use_sts_cd.equals("01")) {// 사용완료된경우
								if (sts_div.equals("00")) {// 사용 조회할 경우
									resp_code = "0001";
									resp_str = "이미 사용한 쿠폰입니다.";
								}
								if (sts_div.equals("01")) {// 사용 조회할 경우
									resp_code = "0001";
									resp_str = "이미 사용한 쿠폰입니다.";
								}
							}
							if (cp_use_sts_cd.equals("00")) {// 조회 완료된경우
								if (sts_div.equals("00")) {// 사용 조회할 경우
									if (!cp_cofm_dt.equals("N")) {
										resp_code = "0007";
										resp_str = "기조회된 쿠폰입니다.조회 취소하세요.";
									}
								}
							}
							System.out.println(cp_use_sts_cd + ":전문구분:" + sts_div);
						}
					}
				}
				// System.out.println("prcPos: 6");
				// if (!resp_code.equals("0000")) {
				if (check2.equals("E")) {// 바코드 유무체크
					resp_code = "0003";
					resp_str = "해당 바코드가 존재하지 않습니다";
				} else if (check5.equals("E")) {
					resp_code = "0006";
					resp_str = "해당 테넌트에서 사용 가능한 쿠폰이 아닙니다";
				} else if (check1.equals("E")) {
					if (sts_div.equals("00")) {// 조회 모드에만 사용기간 체크
						resp_code = "0002";
						resp_str = "쿠폰 사용기한이 지났습니다";
					}
				} else if (check3.equals("E")) {// 최소 사용금액 체크
					resp_code = "0004";
					resp_str = "최소 사용금액이 부족합니다";
				} else if (check4.equals("E")) {// 쿠폰종류 체크
					resp_code = "0005";
					resp_str = "쿠폰 종류가 상이합니다";
				}
				/*
				 * System.out.println("Server: 매출금액:" + sale_evt_cd);
				 * System.out.println("Server: 쿠폰적용방법:" + cp_app_meth);
				 * System.out.println("Server: 매출금액:" + cp_app_amt);
				 */
				// }
				// System.out.println("prcPos: 7");
				byte[] resp_rtn_data = resp_str.getBytes("EUC_KR");
				// byte[] resp_rtn_data=resp_str.getBytes();
				resp_msg = spaceSet(resp_str, resp_rtn_data.length);
				// System.out.println("Server: 에러체크:" + resp_msg);

				// 최종길이 체크
				// 조합리턴
				// String sts_len=msg.substring(0, 4);// 전문길이4
				sts_len = "0200";
				// cp_app_meth="2";
				res_ext_val = "                                   ";
				r_Str = sts_len + sts_div + req_dt + req_tm + jp_cd + tnt_cd + pos_no + deal_no + cacher_no + sale_dt
						+ sale_tm + cp_type + cp_no + sale_amt + resp_code + resp_msg + sale_evt_cd + cp_app_meth
						+ cp_app_amt + cp_max_sale_amt + res_ext_val;

				clv.sts_div = orig_sts_div;
				clv.req_dt = req_dt;
				clv.req_tm = req_tm;
				clv.jp_cd = jp_cd;
				clv.tnt_cd = tnt_cd;
				clv.pos_no = pos_no;
				clv.deal_no = deal_no;
				clv.cacher_no = cacher_no;
				clv.sale_dt = sale_dt;
				clv.sale_tm = sale_tm;
				clv.cp_type = cp_type;
				clv.cp_no = cp_no;
				clv.sale_amt = sale_amt;
				clv.resp_code = resp_code;
				clv.resp_msg = resp_msg;
				clv.sale_evt_cd = sale_evt_cd;
				clv.cp_app_meth = cp_app_meth;
				clv.cp_app_amt = cp_app_amt;
				clv.cp_max_sale_amt = cp_max_sale_amt;

				sqlSession.insert("starfield.mapper.insertCouponPrcLog", clv);
				rtnMsgByte = r_Str.getBytes("EUC_KR");

				if (resp_code.equals("0000")) {// 에러가 아닌 경우
					if (result3List != null) {
						if (result3List.size() == 1) {
							couponDnUseVO.cp_iss_bcd_id = cp_no;
							couponDnUseVO.cp_use_sts_cd = sts_div;
							couponDnUseVO.bcn_cd = jp_cd;
							couponDnUseVO.busi_tnt_cd = tnt_cd;
							couponDnUseVO.pos_no = pos_no;
							if (sts_div.equals("09")) {// 조회 모드에만 사용기간 체크
								couponDnUseVO.cncl_deal_no = deal_no;
							} else {
								couponDnUseVO.deal_no = deal_no;
							}
							sqlSession.update("starfield.mapper.updateUseSts", couponDnUseVO);
						}
					}

				} else if (resp_code.equals("0007")) {// 에러가 아닌 경우
					// couponDnUseVO.cp_iss_bcd_id = cp_no;
					// couponDnUseVO.cp_use_sts_cd = sts_div;
					// sqlSession.update("starfield.mapper.updateUseSts",
					// couponDnUseVO);
				}
				writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg,r_Str, "res");
			}
			setDbInfoEnd();

		} catch (IOException e) {
			setDbInfoEnd();
			writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg + "|" + e, "err");
		} catch (Exception e) {
			setDbInfoEnd();
			writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg + "|" + e, "err");
		} finally {
			// setDbInfoEnd();
			return rtnMsgByte;
		}

	}

	// 조회처리(사용처리_선처리)
	@SuppressWarnings("finally")
	public byte[] prcPosByte(String sendMsg) {

		String msg = sendMsg;// 조회
		String msg2 = "안녕하세요";
		String r_Str = "";
		String subFileNm1 = "";
		String cp_cofm_dt = "";
		byte[] rtnMsgByte = new byte[200];
		String res_ext_val = "                                   ";
		// 조회 전문
		String sts_len = ""; // 전문길이4
		String sts_div = ""; // 전문구분 조회:00 사용완료 : '01', 사용취소:09 망상취소:90 조회취소:02
		String orig_sts_div = ""; // 전문구분 조회:00 사용완료 : '01',
		String req_dt = ""; // 조회일자8
		String req_tm = "";// 조회시간6
		String jp_cd = "";// 점포코드2
		String tnt_cd = "";// 테넌트코드4
		String pos_no = "";// 포스번호 4
		String deal_no = "";// 거래번호 4
		String cacher_no = "";// Casher번호
		String sale_dt = "";// 영업일자8
		String sale_tm = "";// 영업시간6
		String cp_type = "";// 쿠폰유형1 1:에누리 2:할인
		String cp_no = "";// 쿠폰번호 18 바코드번호
		String sale_amt = "";// 매출금액

		String resp_code = "0000";
		String resp_str = "정상";
		String resp_msg = "";
		String check1 = "";// 유효일자체크
		String check2 = "S";// 바코드유무
		String check3 = "";// 최소사용금액체크
		String check4 = "";// 쿠폰종류체크
		String check5 = "";// 해당 테넌트에서 사용 가능 쿠폰인지 조회
		String check6 = "";// 조회 전문 길이체크
		String check7 = "";// 조회 중복 체크

		// 응답시에만 사용
		String rtn_cd = "";// 응답코드 0000 '정상', '0001' : 미발행, '0002': 이미사용, 그 외
		String rtn_msg = "";// 응답메시지 60
		String sale_evt_cd = "";// 행사코드 9
		String cp_app_meth = "";// 쿠폰적용방법 1:금액 2:율(DB)
		String cp_app_amt = "";// 쿠폰적용값 11(DB)
		String cp_max_sale_amt = "";// 쿠폰최대할인값 11(DB)
		String cp_kind_cd = "";
		String cp_use_sts_cd = "";
		String ext_val = "";// 여유필드 119 //공통

		try {
			setDbInfoLoad();
			// 로그 남기기
			// 전문관련 변수
			/*
			 * sts_len = msg.substring(0, 4); // 전문길이4 sts_div =
			 * msg.substring(4, 6); // 전문구분 조회:00 사용완료 : '01', 사용취소:09 망상취소:90
			 * 조회취소:02 orig_sts_div = msg.substring(4, 6); // 전문구분 조회:00 사용완료 :
			 * '01', req_dt = msg.substring(6, 14); // 조회일자8 req_tm =
			 * msg.substring(14, 20);// 조회시간6 jp_cd = msg.substring(20, 22);//
			 * 점포코드2 tnt_cd = msg.substring(22, 26);// 테넌트코드4 pos_no =
			 * msg.substring(26, 30);// 포스번호 4 deal_no = msg.substring(30,
			 * 34);// 거래번호 4 cacher_no = msg.substring(34, 40);// Casher번호
			 * sale_dt = msg.substring(40, 48);// 영업일자8 sale_tm =
			 * msg.substring(48, 54);// 영업시간6 cp_type = msg.substring(54, 55);//
			 * 쿠폰유형1 1:에누리 2:할인 cp_no = msg.substring(55, 73);// 쿠폰번호 18 바코드번호
			 * sale_amt = msg.substring(73, 84);// 매출금액
			 */
			try {
				sts_div = msg.substring(4, 6);// 전문구분 조회:00 사용완료 :
			} catch (StringIndexOutOfBoundsException e) {
				sts_div = "";
			}
			try {
				orig_sts_div = msg.substring(4, 6);// 전문구분 조회:00 사용완료 :
			} catch (StringIndexOutOfBoundsException e) {
				orig_sts_div = "";
			}
			req_dt = msg.substring(6, 14);// 조회일자8
			try {
				req_dt = msg.substring(6, 14);// 조회일자8
			} catch (StringIndexOutOfBoundsException e) {
				req_dt = "";
			}
			try {
				req_tm = msg.substring(14, 20);// 조회시간6
			} catch (StringIndexOutOfBoundsException e) {
				req_tm = "";
			}
			try {
				jp_cd = msg.substring(20, 22);// 점포코드2
			} catch (StringIndexOutOfBoundsException e) {
				jp_cd = "";
			}
			try {
				tnt_cd = msg.substring(22, 26);// 테넌트코드4
			} catch (StringIndexOutOfBoundsException e) {
				tnt_cd = "";
			}
			try {
				pos_no = msg.substring(26, 30);// 포스번호 4
			} catch (StringIndexOutOfBoundsException e) {
				pos_no = "";
			}

			try {
				deal_no = msg.substring(30, 34);// 거래번호 4
			} catch (StringIndexOutOfBoundsException e) {
				deal_no = "";
			}
			try {
				cacher_no = msg.substring(34, 40);// Casher번호
			} catch (StringIndexOutOfBoundsException e) {
				cacher_no = "";
			}
			try {
				sale_dt = msg.substring(40, 48);// 영업일자8
			} catch (StringIndexOutOfBoundsException e) {
				sale_dt = "";
			}

			try {
				sale_tm = msg.substring(48, 54);// 영업시간6
			} catch (StringIndexOutOfBoundsException e) {
				sale_tm = "";
			}
			try {
				cp_type = msg.substring(54, 55);// 쿠폰유형1 1:에누리 2:할인
			} catch (StringIndexOutOfBoundsException e) {
				cp_type = "";
			}
			try {
				cp_no = msg.substring(55, 73);// 쿠폰번호 18 바코드번호
			} catch (StringIndexOutOfBoundsException e) {
				cp_no = "";
			}

			try {
				sale_amt = msg.substring(73, 84);// 매출금액
			} catch (StringIndexOutOfBoundsException e) {
				sale_amt = "";
			}
			CouponLogVO clv = new CouponLogVO();
			// SqlSession
			sqlSession = sqlSessionFactory.openSession();
			if (checkLengMsg(msg).equals("N")) {// 바이트 길이가 작을때
				//System.out.println("prcPos: 211111");
				rtnMsgByte = checkLengSendMsg(msg); //
				clv.sts_div = orig_sts_div;
				clv.req_dt = req_dt;
				clv.req_tm = req_tm;
				clv.jp_cd = jp_cd;
				clv.tnt_cd = tnt_cd;
				clv.pos_no = pos_no;
				clv.deal_no = deal_no;
				clv.cacher_no = cacher_no;
				clv.sale_dt = sale_dt;
				clv.sale_tm = sale_tm;
				clv.cp_type = cp_type;
				clv.cp_no = cp_no;
				clv.sale_amt = sale_amt;
				clv.resp_code = "0010";
				clv.resp_msg = "전문길이이상";
				clv.sale_evt_cd = "";
				clv.cp_app_meth = "";
				clv.cp_app_amt = "";
				clv.cp_max_sale_amt = "";
				subFileNm1 = jp_cd + tnt_cd;
				
				//String pos_no, String cp_no, String resultMsg,
				
				writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg, "req");
				sqlSession.insert("starfield.mapper.insertCouponPrcLog", clv);
			} else {
				//System.out.println("prcPos: 311111");

				sts_len = msg.substring(0, 4); // 전문길이4
				sts_div = msg.substring(4, 6); // 전문구분 조회:00 사용완료 : '01',
												// 사용취소:09 망상취소:90 조회취소:02
				orig_sts_div = msg.substring(4, 6); // 전문구분 조회:00 사용완료 : '01',
				req_dt = msg.substring(6, 14); // 조회일자8
				req_tm = msg.substring(14, 20);// 조회시간6
				jp_cd = msg.substring(20, 22);// 점포코드2
				tnt_cd = msg.substring(22, 26);// 테넌트코드4
				pos_no = msg.substring(26, 30);// 포스번호 4
				deal_no = msg.substring(30, 34);// 거래번호 4
				cacher_no = msg.substring(34, 40);// Casher번호
				sale_dt = msg.substring(40, 48);// 영업일자8
				sale_tm = msg.substring(48, 54);// 영업시간6
				cp_type = msg.substring(54, 55);// 쿠폰유형1 1:에누리 2:할인
				cp_no = msg.substring(55, 73);// 쿠폰번호 18 바코드번호
				sale_amt = msg.substring(73, 84);// 매출금액

				subFileNm1 = jp_cd + tnt_cd;
				writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg, "req");

				sale_evt_cd = cp_no.substring(0, 9);// 행사코드 9

				// System.out.println("prcPos: 3");
				/*
				System.out.println("Server: 전문길이:" + sts_len + " 전문구분:" + sts_div);
				System.out.println("Server: 조회일자" + req_dt + " 조회시간:" + req_tm);
				System.out.println("Server: 점포코드" + jp_cd + " 테넌트코드:" + tnt_cd);
				System.out.println("Server: 포스번호:" + pos_no + " 거래번호:" + deal_no + " Casher번호:" + cacher_no);
				System.out.println("Server: 영업일자:" + sale_dt + " 영업시간:" + sale_tm);
				System.out.println("Server: 쿠폰유형:" + cp_type + " 쿠폰번호:" + cp_no);
				System.out.println("Server: 매출금액:" + sale_amt);
				*/
				CouponVO couponVO = new CouponVO();
				CouponIssMstVO couponIssMstVO = new CouponIssMstVO();
				CouponDnUseVO couponDnUseVO = new CouponDnUseVO();
				// 쿠폰마스터 조회를 위한 셋팅
				couponVO.cp_iss_bcd_id = cp_no;
				couponVO.sale_amt = sale_amt;
				couponVO.sts_div = sts_div;
				couponVO.busi_tnt_cd = tnt_cd;
				couponVO.cp_use_sts_cd =sts_div;
				couponVO.cp_kind_cd =cp_type;
				// 쿠폰바코드조회를 위한 셋팅
				couponIssMstVO.cp_iss_bcd_id = cp_no;
				couponIssMstVO.busi_tnt_cd = tnt_cd;
				couponIssMstVO.bcn_cd = jp_cd;

				couponDnUseVO.cp_iss_bcd_id = cp_no;

				CouponVO result = sqlSession.selectOne("starfield.mapper.selectCouponMst", couponVO);// 쿠폰마스터조회
				//CouponIssMstVO result2 = sqlSession.selectOne("starfield.mapper.selectCouponIss", couponIssMstVO);// 쿠폰바코드조회
				//List<CouponDnUseVO> result3List = sqlSession.selectList("starfield.mapper.selectCouponDownUse",couponDnUseVO);// 쿠폰바코드조회
				CouponDnUseVO result3 = new CouponDnUseVO();
				CouponIssMstVO result4 = new CouponIssMstVO();

				if (result == null) {
					//resp_code = "0003";
					resp_str = "해당 바코드의 쿠폰이 존재하지 않습니다";
				} else {
					//check1 = result.check1;
					//check3 = result.check3;
					//check7 = result.check7;
					resp_code = result.resp_code;
					//System.out.println("rtnMsgByteresp_code>>>>>>>>>>>>>>>>>"+resp_code);
					cp_app_amt = result.cp_app_amt;// 쿠폰적용금액//던질값
					cp_max_sale_amt = result.cp_max_sale_amt;// 던질값
					cp_app_meth = result.cp_sale_div_cd;// 던질값
					cp_kind_cd = result.cp_kind_cd;// 던질값
					//System.out.println("체크>>>>>>>:" + resp_code);
					//if (!cp_type.equals(cp_kind_cd)) {
						//check4 = "E";
					//}
					//System.out.println(cp_type + ":쿠폰유형:" + cp_kind_cd);

					//result4 = sqlSession.selectOne("starfield.mapper.selectCouponTntChk", couponIssMstVO);// 해당 테넌트에서 사용 쿠폰인지 조회

					//if (result4 == null) {
						//check5 = "E";
					//}
				}
				if(resp_code.equals("0001")){
					resp_str = "이미 사용한 쿠폰입니다.";
				}
				if(resp_code.equals("0002")){
					resp_str = "쿠폰 사용기한이 지났습니다.";
				}
				if(resp_code.equals("0003")){
					resp_str = "해당 바코드가 존재하지 않습니다.";
				}
				if(resp_code.equals("0004")){
					resp_str = "최소 사용금액이 부족합니다.";
				}
				if(resp_code.equals("0005")){
					resp_str = "쿠폰 종류가 상이합니다.";
				}
				if(resp_code.equals("0006")){
					resp_str = "해당 테넌트에서 사용 가능한 쿠폰이 아닙니다.";
				}
				if(resp_code.equals("0007")){
					resp_str = "기조회된 쿠폰입니다.조회 취소하세요.";
				}
				/*
				if (result2 == null) {// 바코드 유무
					check2 = "E";
					
				}
				if (result3List != null) {
					if (result3List.size() == 1) {
						result3 = (CouponDnUseVO) result3List.get(0);
						if (result3 == null) {
						} else {
							cp_use_sts_cd = result3.cp_use_sts_cd;
							cp_cofm_dt = result3.cp_cofm_dt;
							if (cp_use_sts_cd.equals("01")) {// 사용완료된경우
								if (sts_div.equals("00")) {// 사용 조회할 경우
									resp_code = "0001";
									resp_str = "이미 사용한 쿠폰입니다.";
								}
								if (sts_div.equals("01")) {// 사용 조회할 경우
									resp_code = "0001";
									resp_str = "이미 사용한 쿠폰입니다.";
								}
							}
							if (cp_use_sts_cd.equals("00")) {// 조회 완료된경우
								if (sts_div.equals("00")) {// 사용 조회할 경우
									if (!cp_cofm_dt.equals("N")) {
										resp_code = "0007";
										resp_str = "기조회된 쿠폰입니다.조회 취소하세요.";
									}
								}
							}
							System.out.println(cp_use_sts_cd + ":전문구분:" + sts_div);
						}
					}
				}
				*/
				// System.out.println("prcPos: 6");
				// if (!resp_code.equals("0000")) {
				/*
				if (check2.equals("E")) {// 바코드 유무체크
					resp_code = "0003";
					resp_str = "해당 바코드가 존재하지 않습니다";
				} else if (check5.equals("E")) {
					resp_code = "0006";
					resp_str = "해당 테넌트에서 사용 가능한 쿠폰이 아닙니다";
				} else if (check1.equals("E")) {
					if (sts_div.equals("00")) {// 조회 모드에만 사용기간 체크
						resp_code = "0002";
						resp_str = "쿠폰 사용기한이 지났습니다";
					}
				} else if (check3.equals("E")) {// 최소 사용금액 체크
					resp_code = "0004";
					resp_str = "최소 사용금액이 부족합니다";
				} else if (check4.equals("E")) {// 쿠폰종류 체크
					resp_code = "0005";
					resp_str = "쿠폰 종류가 상이합니다";
				}
				*/
				/*
				 * System.out.println("Server: 매출금액:" + sale_evt_cd);
				 * System.out.println("Server: 쿠폰적용방법:" + cp_app_meth);
				 * System.out.println("Server: 매출금액:" + cp_app_amt);
				 */
				// }
				// System.out.println("prcPos: 7");
				byte[] resp_rtn_data = resp_str.getBytes("EUC_KR");
				// byte[] resp_rtn_data=resp_str.getBytes();
				resp_msg = spaceSet(resp_str, resp_rtn_data.length);
				// System.out.println("Server: 에러체크:" + resp_msg);

				// 최종길이 체크
				// 조합리턴
				// String sts_len=msg.substring(0, 4);// 전문길이4
				sts_len = "0200";
				// cp_app_meth="2";
				res_ext_val = "                                   ";
				r_Str = sts_len + sts_div + req_dt + req_tm + jp_cd + tnt_cd + pos_no + deal_no + cacher_no + sale_dt
						+ sale_tm + cp_type + cp_no + sale_amt + resp_code + resp_msg + sale_evt_cd + cp_app_meth
						+ cp_app_amt + cp_max_sale_amt + res_ext_val;

				clv.sts_div = orig_sts_div;
				clv.req_dt = req_dt;
				clv.req_tm = req_tm;
				clv.jp_cd = jp_cd;
				clv.tnt_cd = tnt_cd;
				clv.pos_no = pos_no;
				clv.deal_no = deal_no;
				clv.cacher_no = cacher_no;
				clv.sale_dt = sale_dt;
				clv.sale_tm = sale_tm;
				clv.cp_type = cp_type;
				clv.cp_no = cp_no;
				clv.sale_amt = sale_amt;
				clv.resp_code = resp_code;
				clv.resp_msg = resp_msg;
				clv.sale_evt_cd = sale_evt_cd;
				clv.cp_app_meth = cp_app_meth;
				clv.cp_app_amt = cp_app_amt;
				clv.cp_max_sale_amt = cp_max_sale_amt;

				sqlSession.insert("starfield.mapper.insertCouponPrcLog", clv);
				System.out.println("r_Str>>>>>>>>>>>>>>>>>"+r_Str);
				rtnMsgByte = r_Str.getBytes("EUC_KR");
				//System.out.println("rtnMsgByte>>>>>>>>>>>>>>>>>"+rtnMsgByte);
				if (resp_code.equals("0000")) {// 에러가 아닌 경우
					//if (result3List != null) {
						//if (result3List.size() == 1) {
							couponDnUseVO.cp_iss_bcd_id = cp_no;
							couponDnUseVO.cp_use_sts_cd = sts_div;
							couponDnUseVO.bcn_cd = jp_cd;
							couponDnUseVO.busi_tnt_cd = tnt_cd;
							couponDnUseVO.pos_no = pos_no;
							if (sts_div.equals("09")) {// 조회 모드에만 사용기간 체크
								couponDnUseVO.cncl_deal_no = deal_no;
							} else {
								couponDnUseVO.deal_no = deal_no;
							}
							sqlSession.update("starfield.mapper.updateUseSts", couponDnUseVO);
						//}
					//}

				} else if (resp_code.equals("0007")) {// 에러가 아닌 경우
					// couponDnUseVO.cp_iss_bcd_id = cp_no;
					// couponDnUseVO.cp_use_sts_cd = sts_div;
					// sqlSession.update("starfield.mapper.updateUseSts",
					// couponDnUseVO);
				}
				writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg,r_Str, "res");
			}
			//setDbInfoEnd();

		} catch (IOException e) {
			//setDbInfoEnd();
			writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg + "|" + e, "err");
		} catch (Exception e) {
			//setDbInfoEnd();
			writeFile(subFileNm1, tnt_cd, pos_no, cp_no, resp_msg, sendMsg + "|" + e, "err");
		} finally {
			setDbInfoEnd();
			return rtnMsgByte;
		}

	}

	// 바이트 길이 작을 경우 에러 전문 리턴
	private String checkLengMsg(String msg) {
		String chk = "Y";
		int sts_len = 0;
		// System.out.println("msg>>>>>>>>>>>>>>>>>"+sts_len);

		int sts_div = 0;
		int req_dt = 0;
		int req_tm = 0;
		int jp_cd = 0;
		int tnt_cd = 0;
		int pos_no = 0;
		int deal_no = 0;
		int cacher_no = 0;
		int sale_dt = 0;
		int sale_tm = 0;
		int cp_type = 0;
		int cp_no = 0;
		int sale_amt = 0;
		int ext = 0;
		int tot_leng = 0;
		
		 try{ sts_len = msg.substring(0, 4).trim().length();// 전문길이4
		 }catch(StringIndexOutOfBoundsException e){ sts_len=0; } 
		 try{ sts_div= msg.substring(4, 6).trim().length();// 전문구분 조회:00 사용완료 :
		 }catch(StringIndexOutOfBoundsException e){ sts_div=0; } 
		 try{ req_dt =msg.substring(6, 14).trim().length();// 조회일자8
		 }catch(StringIndexOutOfBoundsException e){ req_dt=0; } 
		 try{ req_tm =msg.substring(14, 20).trim().length();// 조회시간6
		 }catch(StringIndexOutOfBoundsException e){ req_tm=0; } 
		 try{ jp_cd =msg.substring(20, 22).trim().length();// 점포코드2
		 }catch(StringIndexOutOfBoundsException e){ jp_cd=0; } 
		 try{ tnt_cd =msg.substring(22, 26).trim().length();// 테넌트코드4
		 }catch(StringIndexOutOfBoundsException e){ tnt_cd=0; } 
		 try{ pos_no =
		 msg.substring(26, 30).trim().length();// 포스번호 4
		 }catch(StringIndexOutOfBoundsException e){ pos_no=0; }
		  
		 try{ deal_no = msg.substring(30, 34).trim().length();// 거래번호 4
		 }catch(StringIndexOutOfBoundsException e){ deal_no=0; } try{
		 cacher_no = msg.substring(34, 40).trim().length();// Casher번호
		 }catch(StringIndexOutOfBoundsException e){ cacher_no=0; } try{
		 sale_dt = msg.substring(40, 48).trim().length();// 영업일자8
		 }catch(StringIndexOutOfBoundsException e){ sale_dt=0; }
		 
		 
		 try{ sale_tm = msg.substring(48, 54).trim().length();// 영업시간6
		 }catch(StringIndexOutOfBoundsException e){ sale_tm=0; } try{ cp_type
		 = msg.substring(54, 55).trim().length();// 쿠폰유형1 1:에누리 2:할인
		 }catch(StringIndexOutOfBoundsException e){ cp_type=0; } try{ cp_no =
		 msg.substring(55, 73).trim().length();// 쿠폰번호 18 바코드번호
		 }catch(StringIndexOutOfBoundsException e){ cp_no=0; }
		 
		 try{ sale_amt = msg.substring(73, 84).trim().length();// 매출금액
		 }catch(StringIndexOutOfBoundsException e){ sale_amt=0; }
		 
		 try{ ext = msg.substring(84, 200).length();
		 }catch(StringIndexOutOfBoundsException e){ ext=0; }
		 
		 tot_leng = sts_len + sts_div + req_dt + req_tm + jp_cd + tnt_cd +
		 pos_no + deal_no + cacher_no + sale_dt + sale_tm + cp_type + cp_no +
		 sale_amt + ext;
		 
		System.out.println("길이합" + tot_leng);
		//System.out.println("길이합" + msg.trim().length());
		//System.out.println("길이합" + msg.length());
		if (tot_leng == 200) {
		//if (msg.length() == 200) {
			chk = "Y";
		} else {
			chk = "N";
		}
		return chk;
	}

	// 바이트 길이 작을 경우 에러 전문 리턴
	private static byte[] checkLengSendMsg(String msg) {
		// 전문관련 변수
		String sts_len = "0200";// 전문길이4
		// System.out.println("msg>>>>>>>>>>>>>>>>>"+sts_len);
		String sts_div = msg.substring(4, 6);// 전문구분 조회:00 사용완료 : '01', 사용취소
												// :
		// System.out.println("sts_div>>>>>>>>>>>>>>>>>"+sts_div); // '09',
		// 망상취소
		// '90'
		String req_dt = "12345678";// 조회일자8
		String req_tm = "123456";// 조회시간6
		String jp_cd = "00";// 점포코드2
		String tnt_cd = "0000";// 테넌트코드4
		String pos_no = "1234";// 포스번호 4

		String deal_no = "1234";// 거래번호 4
		String cacher_no = "123456";// Casher번호
		String sale_dt = "12345678";// 영업일자8
		String sale_tm = "123456";// 영업시간6
		String cp_type = "1";// 쿠폰유형1 1:에누리 2:할인
		String cp_no = "123456789123456789";// 쿠폰번호 18 바코드번호
		String sale_amt = "12345678901";// 매출금액

		String resp_code = "0010";
		String resp_msg = "전문길이이상";
		byte[] resp_rtn_data = new byte[60];
		try {
			resp_rtn_data = resp_msg.getBytes("EUC_KR");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// byte[] resp_rtn_data=resp_str.getBytes();
		resp_msg = spaceSet(resp_msg, resp_rtn_data.length);

		String sale_evt_cd = "123456789";
		String cp_app_meth = "1";
		String cp_app_amt = "12345678912";
		String cp_max_sale_amt = "12345678912";
		String res_ext_val = "12345678901234567890";
		String r_Str = sts_len + sts_div + req_dt + req_tm + jp_cd + tnt_cd + pos_no + deal_no + cacher_no + sale_dt
				+ sale_tm + cp_type + cp_no + sale_amt + resp_code + resp_msg + sale_evt_cd + cp_app_meth + cp_app_amt
				+ cp_max_sale_amt + res_ext_val;
		//System.out.println("길이오류>>" + r_Str);
		byte[] resp1 = new byte[200];
		try {
			resp1 = r_Str.getBytes("EUC_KR");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resp1;
	}

	public static String spaceSet(String str, int len) {
		String rs = "";
		String spaceStr = "";
		int len2 = 60 - len;
		for (int i = 0; i < len2; i++) {
			spaceStr = spaceStr + " ";
		}
		rs = str + spaceStr;
		return rs;
	}

	// throws IOException
	public static void setDbInfoLoad() {
		try {
			inputStream = Resources.getResourceAsStream(configFile);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			//inputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setDbInfoEnd() {
		try {
			// inputStream = Resources.getResourceAsStream(configFile);
			// sqlSessionFactory = new
			// SqlSessionFactoryBuilder().build(inputStream);
			inputStream.close();
			sqlSession.commit();
			sqlSession.close();
			
			sqlSession =null;
			inputStream =null;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	 *  p:전문
	 */
	public static void writeFile(String subFileNm, String tnt_no, String pos_no, String cp_no, String resultMsg, String p, String div) {
		Date d = new Date();
		String now = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String now_time = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date());
		//System.out.println("dateFormat2>>>>" + now);

		// usr/local/src/posd/logs
		try {
			String rootDir = "D:\\";
			// rootDir="D:\\logs\\"+div+"\\";
			rootDir = "/usr/local/src/posd/logs/" + div + "/";
			rootDir="./logs/"+div+"/";
			File dir = new File(rootDir);
			// dir.mkdir();
			// dir.mkdirs();
			if (!dir.exists()) {
				// dir.mkdir();

				if (dir.mkdirs()) {
					//System.out.println("Directory is created!");
				} else {
					//System.out.println("Failed to create directory!");
				}

			}

			// String path = rootDir + subFileNm + "_" + subfileNm2 + "_" + div
			// + ".log";
			//String path = rootDir + div + "_" + now + ".log"; //임시
			String path = rootDir  + now + ".log"; //임시
			//String path = "D:\\"  + now + ".log";
			//System.out.println("path>>>>" + path);
			// 파일 객체 생성
			// File file = new File(path);
			File file = new File(path);
			// true 지정시 파일의 기존 내용에 이어서 작성
			FileWriter fw = new FileWriter(file, true);

			// 파일안에 문자열 쓰기
			fw.write("\n" + "["+now_time +"][TENNT:"+tnt_no+"][POS:"+pos_no+"]["+cp_no+"][" + resultMsg.trim() + "]["+p+"]");
			fw.flush();

			// 객체 닫기
			fw.close();

		} catch (Exception e) {
			System.out.println("파일로그남기기>>" + e.toString());
			//e.printStackTrace();
		}

	}

	public static void writeFile2(String subFileNm, String p, String div) {
		Date d = new Date();
		String subfileNm2 = String.valueOf(d.getYear()) + String.valueOf(d.getMonth()) + String.valueOf(d.getDate())
				+ String.valueOf(d.getHours()) + String.valueOf(d.getMinutes()) + String.valueOf(d.getSeconds());
		// usr/local/src/posd/logs
		try {
			String rootDir = "D:\\";
			// rootDir="./logs/"+div+"/";
			rootDir = "./logs/" + div + "";
			File dir = new File(rootDir);
			if (!dir.exists()) {
				if (dir.mkdir()) {
					System.out.println("Directory is created!");
				} else {
					System.out.println("Failed to create directory!");
				}
			}

			String path = rootDir + subFileNm + "_" + subfileNm2 + "_" + div + ".log";
			// String path = "D:\\" + subFileNm + "_" + subfileNm2 + "_" + div +
			// ".log";
			System.out.println("path>>>>" + path);
			// 파일 객체 생성
			// File file = new File(path);
			File file = new File(path);
			// true 지정시 파일의 기존 내용에 이어서 작성
			FileWriter fw = new FileWriter(file, false);

			// 파일안에 문자열 쓰기
			fw.write(p);
			fw.flush();

			// 객체 닫기
			fw.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
