package main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class CouponPosRealThreadD {

	public static void main(String[] args) {
		Daemon normal = new Daemon();
		//normal.setDaemon(true);//수정 주석 풀다.
		normal.start();
		//HelloDaemon daemon = new HelloDaemon();
		//daemon.setDaemon(true);
		//normal.setDaemon(true);//수정 주석 풀다.
		
		//daemon.start();
	}
}

class Daemon extends Thread {
	// CouponPosIFD ifd = new CouponPosIFD();

	@Override
	public void run() {
		String msg2;
		// ServerSocket serversocket = null;
		ServerSocket sock = null;
		Socket socket = null;
		try {
			sock = new ServerSocket(9000);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out.println("Server: 서버소켓 생성 성공");
		// socket = serversocket.accept();
		System.out.println("Server: 클라이언트 연결 완료");


		// 공통
		CouponPosIFProcess CPIP = new CouponPosIFProcess();
		String rtnMsg = "";
		// try {
		// ifd.processDeamonSet();
		// } catch (IOException e1) {

		// System.out.println("Exception2>>"+e1.getMessage());
		// }
		OutputStream out = null;
		DataOutputStream dou = null;
		InputStream is = null;
		DataInputStream ois = null;
		StringBuffer sb = null;
		String msg = null;
		byte[] bs = new byte[200];
		byte[] rtnMsgByte = new byte[200];
		while (true) {
			try {

				socket = sock.accept();
				is = socket.getInputStream();

				ois = new DataInputStream(is);
				//bs = new byte[200];
				ois.read(bs);
				sb = new StringBuffer();
				for (byte b : bs) {
					char c = (char) b;
					sb.append(c);
				}
				// 받은 전문의 길이를 체크해서 길이가 부족하면 조
				//rtnMsgByte = new byte[200];
				msg = sb.toString();

				rtnMsgByte = CPIP.prcPosByte(msg); //
				out = socket.getOutputStream();
				dou = new DataOutputStream(out);	
					
				

				dou.write(rtnMsgByte);
				/*
				out.flush();
				dou.flush();
				out.close();
				dou.close();
				*/
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IOException>>" + e.getMessage());
			} catch (Exception e) {
				System.out.println("Exception>>" + e.getMessage());
			}finally{
				try {
					
					//rtnMsgByte = null;
					out.flush();
					dou.flush();
					out.close();
					dou.close();
					is = null;
					ois = null;
					sb=null;
					out = null;
					dou = null;
					msg = null;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
}

class HelloDaemon extends Thread {
	@Override
	public void run() {

		while (true) {
			try {
				Thread.sleep(1000);
				printStackTraces();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void printStackTraces() {
		Map<Thread, StackTraceElement[]> stackTraces = getAllStackTraces();

		for (Map.Entry<Thread, StackTraceElement[]> entry : stackTraces.entrySet()) {
			Thread thread = entry.getKey();
			List<StackTraceElement> elementList = Arrays.asList(entry.getValue());

			System.out.println("### Thread Info nanme=" + thread.getName() + ", daemon=" + thread.isDaemon() + " ###");

			for (StackTraceElement element : elementList) {
				System.out.println(element);
			}

			System.out.println("");
		}
	}

}
