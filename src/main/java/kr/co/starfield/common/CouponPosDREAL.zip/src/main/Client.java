package main;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.commons.lang.StringUtils;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
            //IP주소와 포트번호를 입력하여 Socket 통신을 시작합니다. 127.0.0.1 10.253.42.112
            Socket sock = new Socket("10.253.42.153", 9000);
            OutputStream os = sock.getOutputStream();

    		String prcCd    = "02";
    		String dealNo  = "8888";// 8888
    		String sendDate= "20161210";
    		String sendTime= "123014";
    		String bcnCd   = "01";
    		String tntCdP  = "0017";// 4001
    		String posNo   = "7777";
    		String casherNo= "666666";
    		String saleDate= "20160630";
    		String saleTime= "123010";
    		String cpTp="1";
    		String cpNo = "011609002000000054";
    		String saleAmt="00000050000";
            String sendMsg0000_00 = "0200" + prcCd + sendDate+ sendTime + bcnCd + tntCdP + posNo + dealNo + casherNo + saleDate + saleTime+cpTp
    				+ cpNo + saleAmt;// 테스트완료
            String sendMsg =sendMsg0000_00;
            sendMsg = StringUtils.rightPad(sendMsg0000_00, 200, " ");
    		//sendMsg = "12345678";
            byte[] data=sendMsg.getBytes("EUC_KR");
			DataOutputStream dou = new DataOutputStream(os);
			dou.write(data);
			
			dou.close();
			os.close();
            sock.close();
                
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        
	}

}
