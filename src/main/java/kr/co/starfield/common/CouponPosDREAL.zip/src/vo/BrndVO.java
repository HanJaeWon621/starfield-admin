package vo;

public class BrndVO {
	public String brnd_cd;//브랜드코드
	public String brnd_nm_ko;//브랜드명_한글
	public String brnd_nm_en;//브랜드명_영문
	public String dom_for_div;//국내해외구분
	public String natn_cd;//국가코드
	public int sts;//상태
	public int cnt; 
}
