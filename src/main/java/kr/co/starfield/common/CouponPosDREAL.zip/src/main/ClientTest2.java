package main;

import java.net.*;
import java.util.Scanner;
import java.io.*;

public class ClientTest2 {
	// static String IP = "10.162.246.157";//서버 IP 주소 입력
	static String IP = "10.253.42.112";// 서버 IP 주소 입력
	// static String IP = "10.149.178.150";//서버 IP 주소 입력
	// 테스트 데이터 : ClientTest.java
	
	// 02000020160630123014010017777766666620160630123010101160900200000005400000050000

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		int calCnt=1000;
		int calGrpNo = 2;
		for(int i=0;i<calCnt;i++){
			test(calGrpNo, i, "02000020160630123014010017777766666620160630123010101160900200000005400000050000");
		}

	}
	public static void testGrp(int calGrpNo, String msg) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		int calCnt=20;
		for(int i=0;i<calCnt;i++){
			test(calGrpNo, i,msg);
		}

	}
    public static void test(int calGrpNo, int ordNo, String msg) throws UnknownHostException, IOException{
    	//String msg="02000020160630123014010017777766666620160630123010101160900200000005400000050000";
		Socket socket = new Socket(IP, 9001);

		System.out.print(">>>");

		OutputStream out = socket.getOutputStream();
		DataOutputStream dou = new DataOutputStream(out);
		dou.writeUTF(msg);

		InputStream in = socket.getInputStream();
		DataInputStream din = new DataInputStream(in);

		String remsg = din.readUTF();
		out.flush();
		dou.flush();
		out.close();
		dou.close();
		//return calGrpNo + "그룹" + ordNo +"번째 client: server가 보낸문장" + remsg;
		System.out.println(calGrpNo + "그룹 " +ordNo +"번째 client: server가 보낸문장" + remsg);
		
    }
	/**
	 * @param args
	 * @throws IOException
	 * @throws UnknownHostException
	 */
	public static void main2(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		String msg;
		Socket socket = new Socket(IP, 9001);
		System.out.println("client: 소켓 생성 완료");
		Scanner scan = new Scanner(System.in);
		System.out.println("client: 전송 문장 입력");

		while (true) {
			System.out.print(">>>");
			msg = scan.nextLine();

			OutputStream out = socket.getOutputStream();
			DataOutputStream dou = new DataOutputStream(out);
			dou.writeUTF(msg);

			InputStream in = socket.getInputStream();
			DataInputStream din = new DataInputStream(in);

			String remsg = din.readUTF();

			System.out.println("client: server가 보낸문장" + remsg);
			out.flush();
			dou.flush();
			out.close();
			dou.close();
			if (remsg.equalsIgnoreCase("END")) {
				System.out.println("SOCKET END");
				socket.close();
				break;
			}
		}
	}

}
