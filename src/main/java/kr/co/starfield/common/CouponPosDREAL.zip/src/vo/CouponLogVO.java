package vo;
public class CouponLogVO {
	
	public String log_seq="";
    public String sts_div="";
    public String req_dt="";
    public String req_tm="";
    public String jp_cd="";
    public String tnt_cd="";
    public String pos_no="";
    public String deal_no="";
    public String cacher_no="";
    public String sale_dt="";
    public String sale_tm="";
    public String cp_type="";
    public String cp_no="";
    public String sale_amt="";
    public String resp_code="";
    public String resp_msg="";
    public String sale_evt_cd="";
    public String cp_app_meth="";
    public String cp_app_amt="";
    public String cp_max_sale_amt="";	
}