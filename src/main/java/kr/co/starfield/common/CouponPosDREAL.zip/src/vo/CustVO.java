package vo;

public class CustVO {
	public String  cust_abst_info_seq;
	public String corp_cd;//법인코드
	public String abst_no;//추출번호
	public String abst_dt;//추출일자
	public String prpstp;//용도구분
	public String abst_titl;//추출제목
	public String del_yn;//삭제가능여부
	public int sts;//상태

	public int cnt; 
	public String cust_id;//고객ID
	public String cel_no;//휴대폰번호
	public String email;//이메일
}
